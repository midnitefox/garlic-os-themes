Copy 'catppuccin.cfg' to 'CFW\retroarch\.retroarch\assets\rgui'
Copy 'catppuccin.png' to 'CFW\retroarch\.retroarch\assets\rgui\wallpaper'

To apply:

In RetroArch Main Menu > Settings > User Interface > Appearance
- Change 'Menu Color Theme' to 'Custom' and go back to the Appearance Menu
- Select 'Custom Menu Theme Preset' and choose 'catppuccin'